

<!DOCTYPE html>
    <html lang="en">

    <head>
        <title>Bike Rental Website</title>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link href="Style1.css" rel="stylesheet">
        <!-- Box Icons -->
        <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/boxicons@latest/css/boxicons.min.css">

    </head>

    <body>
        <!--Header-->
        <header>
            <a href="#" class="logo"><img src="1.png" alt="Bike logo"></a>

            <div class="bx bx-menu" id="menu-icon"></div>

            <ul class="navbar">
                <li><a href="#home">Home</a></li>
                <li><a href="#ride">Ride</a></li>
                <li><a href="#services">Services</a></li>
                <li><a href="#about">About</a></li>
                <li><a href="#reviews">Reviews</a></li>
            </ul>
            <div class="header-btn">
                <a href="http://localhost/boss/form.php" class="sign-up">Sign Up</a>
                <a href="http://localhost/boss/login.php" class="sign-in">Sign In</a>
            </div>
        </header>
        <!-- Home Section  -->
        <section class="home" id="home">
            <div class="text">
                <h1><span>Looking to</span><br><span>rent a Bike</span></h1>
                <p style="color: rgb(241, 247, 248);">Looking to rent a Bike? Explore our hassle-free rental services and discover the perfect Tovelar for
                    your next adventure <br> whether it's a weekend getaway or a long road trip.</p>
                <div class="app-store">
                    <img src="1.jpg" alt="App-store">
                    <img src="123.png" alt="Play-store">
                </div>
            </div>
            <div class="form-container">
                <form action="">
                    <div class="input-box">
                        <span>Location</span>
                        <input type="search" name="" id="" placeholder="Search Places">
                    </div>
                    <div class="input-box">
                        <span>Pick-Up Date</span>
                        <input type="date" name="" id="">
                    </div>
                    <div class="input-box">
                        <span>Return Date</span>
                        <input type="date" name="" id="">
                    </div>
                    <div class="header-btn">
                        <a href="submit.php" class="btn">submit</a>

                    </div>
                    
                </form>
            </div>
        </section>
        <!--Ride Section-->
        <section class="ride" id="ride">
            <div class="heading">
                <span>How Its Work</span>
                <h1>Rent With 3 Easy Steps</h1>
                
            </div>
            <div class="ride-container">
                <div class="box">
                    <i class='bx bx-map'></i>
                    <h2>Choose A Location</h2>
                    <P>Use our 'Choose a Location' feature to effortlessly find dealerships, repair shops, and service
                        centers in your area, making Bike shopping and maintenance a breeze.</P>
                </div>

                <div class="box">
                    <i class='bx bx-calendar-check'></i>
                    <h2>Pick-Up Date</h2>
                    <P>Browse our 'Pick Up a Date for Your Bike' section to discover the latest tips, tricks, and trends
                        in Bike detailing and maintenance, ensuring your ride always looks and performs its best</P>
                </div>

                <div class="box">
                    <i class='bx bx-calendar-star'></i>
                    <h2>Book A Bike</h2>
                    <P>In our "Book a Bike" section, you can effortlessly reserve the vehicle of your dreams, making your
                        next adventure on the road a reality.</P>
                </div>
            </div>
        </section>
        <!--Services Section-->
        <section class="services" id="services">
            <div class="heading">
                <span>Best Services</span>
                <h1>Explore Out Top Deals <br> From Top Rated Dealers</h1>
            </div>
            <div class="services-container">
                <div class="box">
                    <div class="box-img">
                        <img src="honda.jpg" alt="Honda">
                    </div>
                    <p>2017</p>
                    <h3>2018 Honda</h3>
                    <h2>₹22000<span>/Month</span></h2>
                    <a href="pyment.php" class="btn">Rent Now</a>
                </div>

                <div class="box">
                    <div class="box-img">
                        <img src="yamaha.jpg" alt="Honda">
                    </div>
                    <p>2017</p>
                    <h3>2018 yamaha</h3>
                    <h2>₹8000<span>/Month</span></h2>
                    <a href="pyment.php" class="btn">Rent Now</a>
                </div>

                <div class="box">
                    <div class="box-img">
                        <img src="ktm.jpg" alt="Honda">
                    </div>
                    <p>2017</p>
                    <h3>2018 KTM</h3>
                    <h2>₹10000<span>/Month</span></h2>
                    <a href="pyment.php" class="btn">Rent Now</a>
                </div>

                <div class="box">
                    <div class="box-img">
                        <img src="bike1.jpg" alt="Honda">
                    </div>
                    <p>2017</p>
                    <h3>2018 black yamaha</h3>
                    <h2>₹20000 <span>/Month</span></h2>
                    <a href="pyment.php" class="btn">Rent Now</a>
                </div>

                <div class="box">
                    <div class="box-img">
                        <img src="bike2.jpg" alt="Honda ">
                    </div>
                    <p>2021</p>
                    <h3>2023 new himalya 450 </h3>
                    <h2>₹48000 <span>/Month</span></h2>
                    <a href="pyment.php" class="btn">Rent Now</a>
                </div>

                <div class="box">
                    <div class="box-img">
                        <img src="bike3.jpg" alt="Honda">
                    </div>
                    <p>2016</p>
                    <h3>2018 splender</h3>
                    <h2>₹18000 <span>/Month</span></h2>
                    <a href="pyment.php" class="btn">Rent Now</a>
                </div>

                <div class="box">
                    <div class="box-img">
                        <img src="bike4.jpg" alt="Police Electronic bike">
                    </div>
                    <p>2022</p>
                    <h3>2023 Police Electronic motor bike </h3>
                    <h2>₹2,451,500  <span>/Month</span></h2>
                    <a href="pyment.php" class="btn">Rent Now</a>
                </div>

                <div class="box">
                    <div class="box-img">
                        <img src="bike5.jpg" alt="bike">
                    </div>
                    <p>1998</p>
                    <h3>2001 power bike</h3>
                    <h2>₹5,00,000 <span>/Month</span></h2>
                    <a href="pyment.php" class="btn">Rent Now</a>
                </div>

                <div class="box">
                    <div class="box-img">
                        <img src="bike6.jpg" alt="bike">
                    </div>
                    <p>2016</p>
                    <h3>2017 Royal Enfield Himalayan</h3>
                    <h2>₹15,00,000 <span>/Month</span></h2>
                    <a href="pyment.php" class="btn">Rent Now</a>
                </div>

                <div class="box">
                    <div class="box-img">
                        <img src="bike7.jpg" alt="bike">
                    </div>
                    <p>2021</p>
                    <h3>2022 This Tesla Cybertruck Inspired Bike</h3>
                    <h2>₹26000 <span>/Month</span></h2>
                    <a href="pyment.php" class="btn">Rent Now</a>
                </div>

                <div class="box">
                    <div class="box-img">
                        <img src="bike8.jpg" alt="bike">
                    </div>
                    <p>2019</p>
                    <h3>2020 BMW</h3>
                    <h2>₹22,00,000 <span>/Month</span></h2>
                    <a href="pyment.php" class="btn">Rent Now</a>
                </div>

                <div class="box">
                    <div class="box-img">
                        <img src="bike9.jpg" alt="kawasaki bike">
                    </div>
                    <p>2006</p>
                    <h3>2008 kawasaki bike</h3>
                    <h2>₹10000<span>/Month</span></h2>
                    <a href="pyment.php" class="btn">Rent Now</a>
                </div>
            </div>
        </section>
        <!--About Section-->
        <section class="about" id="about">
            <div class="heading">
                <span>About Us</span>
                <h1>Best Customer Experience</h1>
            </div>
            <div class="about-container">
                <div class="about-img">
                    <img src="bike7.jpg" alt="">
                </div>
                <div class="about-text">
                    <span>About Us</span>
                    <p>Welcome to our Bike Rental website! At CARZ-Ezy, we are passionate about all things automotive.
                        Our "About Us" page is where you can get to know the driving force behind our platform. Founded
                        by a single of dedicated Bike enthusiasts, our mission is to provide a one-stop destination for
                        Bike lovers of all kinds. Whether you're a gearhead looking for in-depth reviews and technical
                        specs or a casual driver seeking expert advice on buying and maintaining your toveler , we've got
                        you covered.</p>
                    <p> Our team brings decades of combined experience in the automotive industry, and we're here to
                        share our knowledge, insights, and love for cars with you. Explore our site and join our
                        community as we rev up the excitement for all things automotive!</p>
                    <a href="#" class="btn">Learn More</a>
                </div>
            </div>
        </section>
        <!--Reviews Section-->
        <section class="reviews" id="reviews">
            <div class="heading">
                <span>Reviews</span>
                <h1>What Our Customer Say</h1>
            </div>
            <div class="reviews-container">
                <div class="box">
                    <div class="rev-img">
                        <img src="dhoni.jpg" alt="Customer1">
                    </div>
                    <h2>MS Dhoni</h2>
                    <div class="stars">
                        <i class='bx bxs-star'></i>
                        <i class='bx bxs-star'></i>
                        <i class='bx bxs-star'></i>
                        <i class='bx bxs-star'></i>
                        <i class='bx bxs-star-half'></i>
                    </div>
                    <p>"I've been a loyal visitor to this Bike website for years, and it never disappoints. The in-depth
                        reviews, comparisons, and expert insights have guided me through multiple car purchases"</p>
                </div>

                <div class="box">
                    <div class="rev-img">
                        <img src="sushant.jpg" alt="Customer1">
                    </div>
                    <h2>sushant singh </h2>
                    <div class="stars">
                        <i class='bx bxs-star'></i>
                        <i class='bx bxs-star'></i>
                        <i class='bx bxs-star'></i>
                        <i class='bx bxs-star'></i>
                        <i class='bx bxs-star-half'></i>
                    </div>
                    <p>"This car website has made my Bike-buying experience a breeze. The search filters are incredibly
                        helpful in narrowing down my options, and the comprehensive information on each vehicle is
                        exactly what I needed"</p>
                </div>

                <div class="box">
                    <div class="rev-img">
                        <img src="john.jpg" alt="Customer1">
                    </div>
                    <h2>John abraham</h2>
                    <div class="stars">
                        <i class='bx bxs-star'></i>
                        <i class='bx bxs-star'></i>
                        <i class='bx bxs-star'></i>
                        <i class='bx bxs-star'></i>
                        <i class='bx bxs-star-half'></i>
                    </div>
                    <p>"I can't say enough good things about this car website! It's a one-stop-shop for all
                        things automotive. From detailed specs and reviews to a user-friendly interface for
                        finding the perfect Bike , it's a Bike  enthusiast's dream"</p>
                </div>
            </div>
        </section>
        <!--Newsletter Section-->
        <section class="newsletter">
            <h2>Subscribe To Newsletter</h2>
            <div class="box">
                <input type="text" placeholder="Enter your Email....">
                <a href="#" class="btn">Subscribe</a>
            </div>
        </section>
        <div class="copyright">
            <p>&#169;Designed Arju Chavda | Right Reserved</p>

            <div class="social">
                <a href="#"><i class='bx bxl-facebook'></i></a>
                <a href="#"><i class='bx bxl-twitter'></i></a>
                <a href="#"><i class='bx bxl-instagram'></i></a>
            </div>
        </div>
        <!--Scroll Reveal-->
        <script src="https://unpkg.com/scrollreveal"></script>
        <!--link to JS-->
        <script src="main.js"></script>
    </body>

    </html>