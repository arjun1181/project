<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" type="text/css" href="pyment.css">
    <title>Responsive Pyment </title>
</head>
<body>
    <header>
        <div class="container">
            <div class="left">
                <h3>BILLING ADDRESS</h3>
                <form>
                    Full name
                    <input type="text" name="" placeholder="Enter name">
                    Email
                    <input type="text" name="" placeholder="Enter email">
                    Address
                    <input type="text" name="" placeholder="Enter address">
                    Aadhar card
                    <input type="text" name="" placeholder="Enter aadhar num">
                    Driving Licence
                    <input type="text" name="" placeholder="Enter Licence num">
                    City
                    <input type="text" name="" placeholder="Enter city">
                    Pan card
                    <input type="text" name="" placeholder="Enter pancard num">
                    <div id="zip">
                        <label>
                            State
                            <select>
                                <option>Choose State..</option>
                                <option>Rajasthan</option>
                                <option>Gujrat</option>
                                <option>Panjab</option>
                                <option>UP</option>
                                <option>delhi</option>
                                <option>Hariyana</option>
                                <option>Madhya Pradesh</option>
                                
                            </select>
                        </label>
                        <label>
                            Zip code
                            <input type="number" name=""placeholder="Zip code">
                        </label>
                    </div>
                </form>
            </div>
            <div class="right">
            <h3>PAYMENT</h3>
            <form>
                Accepted Caed <br>
                <img src="card.png" width="54">
                <img src="card1.png" width="53">
                <br><br>
                Credit card number
                <input type="text" name="" placeholder="Enter card number">
                Exp month
                <input type="text" name="" placeholder="Enter Month">
                <div id="zip">
                    <label>
                        Exp year
                        <select>
                            <option>Choose year..</option>
                            <option>2023</option>
                            <option>2024</option>
                            <option>2025</option>
                            <option>2026</option>
                            <option>2027</option>
                            <option>2028</option>
                            <option>2029</option>
                            
                        </select>
                    </label>
                    <label>
                        CVV
                        <input type="number" name=""placeholder="CVV">
                    </label>
                </div>
            </form>
            <input type="submit" name="" value="Proceed to Checkout">
            </div>
        </div>
    </header>
</body>
</html>