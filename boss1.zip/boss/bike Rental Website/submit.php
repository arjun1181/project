<!DOCTYPE html>
<html>
<head>
<title>Payment Page</title>
<style>
body {
    font-family: Arial, sans-serif;
}
* {
    margin: 0;
    padding: 0;
    box-sizing: border-box;
    scroll-padding-top: 2rem;
    scroll-behavior: smooth;
    list-style: none;
    text-decoration: none;
    font-family: "poppins", sans-serif;
    }
html::-webkit-scrollbar {
    width: 0.5rem;
    }

html::-webkit-scrollbar-track {
    background: transparent;
    }

html::-webkit-scrollbar-track {
    background: var(--main-color);
    border-radius: 5rem;
    }
.container {
    max-width: 300px;
    padding: 16px;
    background-color: white;
    margin: 0 auto;
    margin-top: 100px;
    border: 1px solid black;
    box-shadow: 2px 2px 10px rgba(0, 0, 0, 0.3);
}
.home {
    width: 100%;
    min-height: 100vh;
    position: relative;
    background: url(homepagebike.png);
    background-repeat: no-repeat;
    background-position: center right;
    background-size: cover;
    display: grid;
    align-items: center;
    grid-template-columns: repeat(2, 1fr);
            }
input[type=text], input[type=email], input[type=tel], select, textarea {
    width: 100%;
    padding: 12px;
    border: 1px solid #ccc;
    border-radius: 4px;
    box-sizing: border-box;
    margin-top: 6px;
    margin-bottom: 16px;
    resize: vertical;
}
input[type=submit] {
    background-color: #4CAF50;
    color: white;
    padding: 14px 20px;
    margin: 8px 0;
    border: none;
    cursor: pointer;
    width: 100%;
    opacity: 0.9;
}
input[type=submit]:hover {
    opacity:1;
}
.btn {
    width: 100%;
    background-color: #4CAF50;
    color: white;
    padding: 14px 20px;
    margin: 8px 0;
    border: none;
    cursor: pointer;
}
.btn:hover {
    opacity: 0.8;
}
.cancelbtn {
    width: auto;
    padding: 10px 18px;
    background-color: #f44336;
}
.imgcontainer {
    text-align: center;
    margin: 24px 0 12px 0;
}
.container {
    padding: 16px;
}
span.psw {
    float: right;
    padding-top: 16px;
}
.secure {
    background-color: #4CAF50;
    color: white;
    padding: 14px 20px;
    margin: 8px 0;
    border: none;
    cursor: pointer;
}
.cancelbtn, .secure {
    width: auto;
    padding: 10px 18px;
    background-color: #f44336;
}
.img {
    width: 10%;
    height: auto;
}
@media screen and (max-width: 300px) {
    span.psw {
       display: block;
       float: none;
    }
    .cancelbtn {
       width: 100%;
    }
}
.text h1 {
            font-size: 7rem;
            letter-spacing: 2px;
        }

        .text span {
            color:#fe5b3d;
        }

        .text p {
        font-size: 3rem;
        margin: 00.5rem 0 1rem;
        border-radius: 2;
        }
        .colorful{
 position: relative;
 display: inline-block;
 padding: 10px;
 background-color: white;
}

.colorful::before {
 content: "";
 position: absolute;
 top: 0;
 left: 0;
 right: 0;
 bottom: 0;
 z-index: -1;
 background: linear-gradient(45deg, red, orange, yellow, green, blue, indigo, violet);
 border-radius: 10px;
}
</style>
</head>
<body>
<section class="home" id="home">
    <div class="text">
        <h1 ><span>Looking to</span><br><span>rent a Bike</span></h1>
        <p class="colorful" style="color: rgb(224, 63, 13);">Make payment and take the bike.</p>
    </div>
<div class="container">
    <form action="/payment" method="post">
        <label for="fname">Full Name</label>
        <input type="text" id="fname" name="firstname" placeholder="Your full name...">

        <label for="email">Email</label>
        <input type="email" id="email" name="email" placeholder="Your email...">

        <label for="phone">Phone</label>
        <input type="tel" id="phone" name="phone" placeholder="Your phone number...">

        <label for="address">Address</label>
        <input type="text" id="address" name="address" placeholder="Your address...">

        <label for="city">City</label>
        <input type="text" id="city" name="city" placeholder="Your city...">

        <label for="state">State</label>
        <input type="text" id="state" name="state" placeholder="Your state...">

        <label for="zip">Zip</label>
        <input type="text" id="zip" name="zip" placeholder="Your zip...">

        
        <input type="submit" value="SUBMIT" class="btn">
    </form>
</div>
</section>
</body>
</html>
