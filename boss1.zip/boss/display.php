<?php
include("conection.php");

$query = "SELECT * FROM FROM";
$data = mysqli_query($conn,$query);

$total = mysqli_num_rows($data);
//echo $total;
if($total !=0)
{
    echo "Table has records";

}
else
{
    echo "No records found";
}
?>