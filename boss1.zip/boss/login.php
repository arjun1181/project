<?php include("conection.php"); ?>

<!DOCTYPE html>
<html>
<head>
    <title>Login Page</title>
    <style>
        body {
            font-family: Arial, Helvetica, sans-serif;
            background-color: aqua;
        }
        .login-container {
            width: 300px;
            margin: 0 auto;
            margin-top: 100px;
            background: #fff;
            padding: 20px;
            border-radius: 5px;
            box-shadow: 0 0 5px 0 #888888;
        }
        .form-group {
            margin-bottom: 20px;
        }
        .form-group label {
            display: block;
        }
        .form-group input {
            width: 100%;
            padding: 10px;
            border: 1px solid #ccc;
            border-radius: 3px;
        }
        .form-group button {
            background: #007BFF;
            color: #fff;
            border: 0;
            border-radius: 3px;
            padding: 10px 15px;
            cursor: pointer;
        }
    </style>
</head>
<body>
    <div class="login-container">
        <h2>Login</h2>
        
        <form action="your-server-url" method="POST">
            <div class="form-group">
                <label for="username">Username:</label>
                <input type="text" id="username" name="username" required>
            </div>
            <div class="form-group">
                <label for="password">Password:</label>
                <input type="password" id="password" name="password" required>
            </div>
            <div class="form-group">
                <button type="submit">Login</button>
            </div>
        </form>
        <p> Not have an accont? <a href="form.php">Sing up here</a>
    </div>
</body>
</html>

<?php
        if($_POST["login"])
        {
        $uname    = $_POST['uname'];
        $pwd      = $_POST['password'];
        

        $query = "INSERT INTO login VALUES('$uname',' $pwd',)";
        $data = mysqli_query($conn,$query);

        if($data)
        {
            echo "Data Insert into Database";
        }
        else
        {
            echo "Failed";
        }
    }
        
        
        ?>
